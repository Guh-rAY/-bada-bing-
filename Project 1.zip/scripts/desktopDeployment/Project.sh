#!/bin/bash
jre/bin/java -XX:MaxRAMPercentage=60 -classpath "lib/*" project.Project
exit 0
